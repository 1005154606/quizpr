/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.*;
import javax.persistence.Id;
import javax.validation.constraints.*;


/**
 *
 * @author Usuario
 */
@Entity
@Table(name="USUARIO")
public class Usuario implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @NotNull
    @Basic(optional=false)
    @Column(name="CORREO")
    @Size(min=16,max=50)
    private String correo;
    @Basic(optional=false)
    @Column(name="CLAVE")
    @NotNull
    @Size(max=50)
    private String clave;
    @NotNull
    @Basic(optional=false)
    @Column(name="ESTADO")
    @Size(max=1)
    private String estado;
    
    @JoinColumn(name="TIPO_USUARIO_ID", referencedColumnName="ID")
    @ManyToOne(optional=false)
    private Tipo_usuario TipoUsuarioID;

   

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (correo != null ? correo.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Usuario)) {
            return false;
        }
        Usuario other = (Usuario) object;
        if ((this.correo == null && other.correo != null) || (this.correo != null && !this.correo.equals(other.correo))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Modelo.USUARIO[ id=" + correo + " ]";
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public Tipo_usuario getTipoUsuarioID() {
        return TipoUsuarioID;
    }

    public void setTipoUsuarioID(Tipo_usuario TipoUsuarioID) {
        this.TipoUsuarioID = TipoUsuarioID;
    }

    
    
   
    
}
