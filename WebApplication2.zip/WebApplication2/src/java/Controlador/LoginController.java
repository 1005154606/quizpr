/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.Usuario;

import java.io.IOException;
import java.io.Serializable;
import javax.ejb.EJB;
import javax.faces.context.FacesContext;
import dao.UsuarioDAO;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.application.FacesMessage;
/**
 *
 * @author Usuario
 */
public class LoginController implements Serializable {

   private Usuario usuario;
   private Usuario usuarioAutenticado=null;
   List<Usuario> listado;
  
   private final static Logger LOGGER = Logger.getLogger("Controlador.LoginController");
   
   @EJB
   private UsuarioDAO ejbdao;
   
   
    public LoginController() {
        usuario=new Usuario();
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }
    public void login() throws IOException{
        FacesContext context= FacesContext.getCurrentInstance();
        
       Object res= ejbdao.encontrarUsuarioPorLogin(usuario.getCorreo(), usuario.getClave());
       if (res!=null){
          LOGGER.log(Level.INFO, "BIENVENIDO");
            context.getExternalContext().redirect("home.xhtml");
       }else{
           LOGGER.log(Level.SEVERE, "NO ENCONTRADO");
          
          
           context.getExternalContext().redirect("index.xhtml");}
     
       
    }
    public List<Usuario> getListado(){
        listado= ejbdao.listar();
        return listado;
    }
}
